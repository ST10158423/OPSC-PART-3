const express = require('express');
const admin = require('firebase-admin');
const app = express();

// Initialize Firebase Admin SDK
const serviceAccount = require('./secrets/trailsntrials-1c44b-firebase-adminsdk-nfkg4-4696b154a6.json');
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://trailsntrials-1c44b-default-rtdb.firebaseio.com/"
});

// Firestore database instance
const db = admin.firestore();

// Middleware to parse JSON
app.use(express.json());

// Root Route Handler - Welcome message
app.get('/', (req, res) => {
  res.status(200).send('Welcome to the Trails & Trials API!');
});

// Endpoint to get all routes
app.get('/routes', async (req, res) => {
  try {
    const routesRef = db.collection('routes');
    const snapshot = await routesRef.get();
    let routes = [];
    snapshot.forEach(doc => {
      routes.push({ id: doc.id, ...doc.data() });
    });
    res.status(200).json(routes);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch routes' });
  }
});

// Endpoint to create a new route with latitude and longitude
app.post('/routes', async (req, res) => {
  const { name, distance, start_point, end_point, difficulty } = req.body;
  if (!start_point || !start_point.latitude || !start_point.longitude ||
      !end_point || !end_point.latitude || !end_point.longitude) {
    return res.status(400).json({ error: "Start and end points must include latitude and longitude" });
  }
  try {
    const newRoute = {
      name,
      distance,
      start_point,  // Expecting { latitude, longitude }
      end_point,    // Expecting { latitude, longitude }
      difficulty,
    };
    const routeRef = await db.collection('routes').add(newRoute);
    res.status(201).json({ id: routeRef.id, ...newRoute });
  } catch (error) {
    res.status(500).json({ error: 'Failed to create new route' });
  }
});

// Endpoint to delete a route by ID
app.delete('/routes/:id', async (req, res) => {
  const { id } = req.params;
  try {
    await db.collection('routes').doc(id).delete();
    res.status(200).json({ message: `Route with ID ${id} deleted successfully` });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete route' });
  }
});

// Start the server on the appropriate port for Google Cloud App Engine or locally
const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});
